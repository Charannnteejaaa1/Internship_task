# Q1. Frequency of each word
def word_frequency(sentence):
    counts = {}
    for word in sentence.lower().split():
        counts[word] = counts.get(word, 0) + 1
    return counts

# Q2. Frequency of each character
def character_frequency(word):
    counts = {}
    for character in word:
        counts[character] = counts.get(character, 0) + 1
    return counts

# Q3. First non-repeating character
def first_non_repeating_character(word):
    counts = character_frequency(word)
    for character in word:
        if counts[character] == 1:
            return character
    return None

# Q4. Check whether two strings are anagrams
def are_anagrams(s1, s2):
    return character_frequency(s1.replace(" ", "").lower()) == character_frequency(s2.replace(" ", "").lower())

# Q5. First repeating character
def first_repeating_character(text):
    seen = set()
    for character in text:
        if character in seen:
            return character
        seen.add(character)
    return None

# Q6. Move all zeros to the end
def move_zeros_to_end(nums):
    non_zeros = [number for number in nums if number != 0]
    return non_zeros + [0] * (len(nums) - len(non_zeros))

# Q7. Second highest distinct number
def second_highest_distinct(nums):
    distinct = sorted(set(nums), reverse=True)
    return distinct[1] if len(distinct) >= 2 else None

# Q8. Remove duplicates without changing order
def remove_duplicates(nums):
    result = []
    seen = set()
    for number in nums:
        if number not in seen:
            result.append(number)
            seen.add(number)
    return result

# Q9. Find the missing number from 1 to N
def missing_number(nums, n):
    return n * (n + 1) // 2 - sum(nums)

# Q10. First pair whose sum equals target
def first_pair_sum(nums, target):
    seen = []
    for number in nums:
        needed = target - number
        for earlier in seen:
            if earlier == needed:
                return [earlier, number]
        seen.append(number)
    return []

# Q11. Number closest to zero (positive wins ties)
def closest_to_zero(nums):
    if not nums:
        return None
    return min(nums, key=lambda number: (abs(number), -number))

# Q12. Common elements, in first-list order
def common_elements(list1, list2):
    second = set(list2)
    result = []
    seen = set()
    for number in list1:
        if number in second and number not in seen:
            result.append(number)
            seen.add(number)
    return result

# Q13. Rotate list right by K positions
def rotate_right(nums, k):
    if not nums:
        return []
    k %= len(nums)
    return nums[-k:] + nums[:-k] if k else nums[:]

# Q14. Maximum sum of two consecutive elements
def max_consecutive_sum(nums):
    return max(nums[index] + nums[index + 1] for index in range(len(nums) - 1))

# Q15. All unique pairs whose sum equals target
def all_pairs_sum(nums, target):
    pairs = set()
    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            if nums[i] + nums[j] == target:
                pairs.add(tuple(sorted((nums[i], nums[j]))))
    return [list(pair) for pair in sorted(pairs)]
